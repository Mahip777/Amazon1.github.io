#include <stdio.h>
#include <math.h>
int main()
{
    float a = 1.1;
    float b = 8.9;
    float c = a + b;
    printf("The value of sum of and b is %f\n", c);
    printf("The value of 4 to the power of 5 is %f\n", pow(4, 5));
    return 0;
}