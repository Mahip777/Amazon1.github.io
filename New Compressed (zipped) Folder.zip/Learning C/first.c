int x = 18
do{

    do{
        printf("%o",x);

    }while(!-2)

}while(0)
}