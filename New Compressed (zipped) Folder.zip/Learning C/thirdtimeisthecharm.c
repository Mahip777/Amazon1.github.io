
// int main(){
//     int a = 4;
//     char c = c;
//     int b = 6;
//     int m = 8;
//     int s = 49;
//     printf("The value of a is %d %d \n", a, a);
//     printf("The value of a is %d %d \n", a, a);
//     printf("The value of s is %d %d \n", s, s);
//     printf("Sum of a and s is %d \n", a + s);
//     return 0;

// }

// set 1 complete


// #include <stdio.h>

// int main ()
// {
//     int a , b;
//     printf("Enter the value of a\n");
//     scanf("%d", &a);

//     printf("Enter the value of b\n");
//     scanf("%d", &b);

//     printf("The sum of a and b is %d", a + b);
//     return 0;
    
// }
// set 2 complete

#include <stdio.h>
int main ()
{
    int radius;
    float pi = 3.14;
   
    printf("The value of the radius of the circle is\n");
    scanf("%d", &radius);
     float area = pi * radius * radius;

    printf("The area of the circle is %f", area);
    return 0;


}
